/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aqua;
import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class db {
    Connection con=null;  
  java.sql.PreparedStatement pst;
  public static Connection dbconnect() 
  {
      try{
          Class.forName("com.mysql.jdbc.Driver");
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bill","root","");
          return conn;
      }
      catch(Exception e2){
        System.out.println(e2);
      return null;
      } 
}
}
